import csv

intent_mappings = {}
with open('./data/nlu/intent_mapping.csv', newline='', encoding='utf-8') as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        intent_mappings[row[0]] = row[1]