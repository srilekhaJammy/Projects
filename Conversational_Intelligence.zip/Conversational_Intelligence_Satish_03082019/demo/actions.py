# -*- coding: utf-8 -*-

import logging

from rasa_core_sdk import Action
from rasa_core_sdk.events import SlotSet, UserUtteranceReverted, \
                                 ConversationPaused
from demo.api import MailChimpAPI
from demo import config

from typing import Dict, Text, Any, List, Union
from rasa_core_sdk import ActionExecutionRejection
from rasa_core_sdk import Tracker
from rasa_core_sdk.executor import CollectingDispatcher
from rasa_core_sdk.forms import FormAction, REQUESTED_SLOT
import datetime
import csv
from yahoo_fin import stock_info as si
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import six
from random import randint
import requests

#from demo.gdrive_service import GDriveService

logger = logging.getLogger(__name__)


class ActionDefaultAskAffirmation(Action):
   """Asks for an affirmation of the intent if NLU threshold is not met."""

   def name(self):
       return "action_default_ask_affirmation"

   def __init__(self):
       self.intent_mappings = {}
       # read the mapping from a csv and store it in a dictionary
       with open('./data/nlu/intent_mapping.csv', newline='', encoding='utf-8') as file:
           csv_reader = csv.reader(file)
           for row in csv_reader:
               self.intent_mappings[row[0]] = row[1]

       print(self.intent_mappings)

   def run(self, dispatcher: 'Dispatcher', tracker: 'DialogueStateTracker', domain: 'Domain'):
       # get the most likely intent
       last_intent_name = tracker.latest_message['intent']['name']
       # get the prompt for the intent
       intent_prompt = self.intent_mappings[last_intent_name]
       if intent_prompt is None:
           intent_prompt = last_intent_name
       # Create the affirmation message and add two buttons to it.
       # Use '/<intent_name>' as payload to directly trigger '<intent_name>'
       # when the button is clicked.
       message = "Did you mean '{}'?".format(intent_prompt)
       buttons = [{'title': 'Yes',
                   'payload': '/{}'.format(last_intent_name)},
                  {'title': 'No',
                   'payload': '/out_of_scope'}]
       dispatcher.utter_button_message(message, buttons=buttons)
       return []


class ActionChitchat(Action):
    """Returns the chitchat utterance dependent on the intent"""

    def name(self):
        return "action_chitchat"

    def run(self, dispatcher, tracker, domain):

        intent = tracker.latest_message['intent'].get('name')

        # retrieve the correct chitchat utterance dependent on the intent
        if intent in ['ask_howdoing',
                      'ask_whatspossible', 'ask_whoisit']:
            dispatcher.utter_template('utter_' + intent, tracker)
        return []

class ActionPause(Action):
    """Pause the conversation"""

    def name(self):
        return "action_pause"

    def run(self, dispatcher, tracker, domain):

        return [ConversationPaused()]
		
class ActionFindHoldings(Action):
    """Returns the holdings utterance dependent on the Asset Class"""

    def name(self):
        return "action_find_holdings"

    def run(self, dispatcher, tracker, domain):

        assetClass = next(tracker.get_latest_entity_values('ENT_AssetClass'), None)

        # retrieve the correct chitchat utterance dependent on the intent
        # if assetClass in ['cash', 'equity', 'alternatives',
        #               'IPO', 'fixed income']:
        #     dispatcher.utter_template('utter_' + assetClass + '_holdings', tracker)
        # return []
        
        #Call database, get the holdings and then utter back

        if not assetClass:
            dispatcher.utter_template('utter_faq_total_holdings', tracker)
            return [SlotSet('ENT_AssetClass', None)]
       
        if assetClass.lower() == 'cash':
            dispatcher.utter_template('utter_cash_holdings', tracker)
        elif assetClass.lower() == 'equity':
            dispatcher.utter_template('utter_equity_holdings', tracker)
        elif assetClass.lower() == 'alternatives' or assetClass.lower() == 'alternative':
            dispatcher.utter_template('utter_alternatives_holdings', tracker)
        elif assetClass.lower() == 'ipo':
            dispatcher.utter_template('utter_ipo_holdings', tracker)
        elif assetClass.lower() == 'fixed income':
            dispatcher.utter_template('utter_fincome_holdings', tracker)
        else:
            dispatcher.utter_template('utter_faq_total_holdings', tracker)
            return [SlotSet('ENT_AssetClass', None)]

        return [SlotSet('ENT_AssetClass', assetClass)]

class ActionFindContactDepartment(Action):
    """Returns the chitchat utterance dependent on the intent"""

    def name(self):
        return "action_find_contact_department"

    def run(self, dispatcher, tracker, domain):

        dept = next(tracker.get_latest_entity_values('ENT_Departments'), None)

        if not dept:
            dispatcher.utter_template('utter_DefaultContact', tracker)
            return [SlotSet('ENT_Departments', None)]

        if dept.lower() == 'sales':
            dispatcher.utter_template('utter_SalesTeamContact', tracker)
        elif dept.lower() == 'customer':
            dispatcher.utter_template('utter_CustomerCareContact', tracker)
        elif dept.lower() == 'portfolio' or dept.lower() == 'portfolios':
            dispatcher.utter_template('utter_PortfolioContact', tracker)
        elif dept.lower() == 'operations':
            dispatcher.utter_template('utter_OperationsContact', tracker)
        elif dept.lower() == 'systems' or dept.lower() == 'system':
            dispatcher.utter_template('utter_SystemsContact', tracker)
        else:
            dispatcher.utter_template('utter_DefaultContact', tracker)
        
        return [SlotSet('ENT_Departments', dept)]

class ActionStoreMaxFrequencyNumber(Action):

    def name(self):
        return "action_store_max_frequency_number"

    def run(self, dispatcher, tracker, domain):
        maxnumber = next(tracker.get_latest_entity_values('ENT_Number'), None)

        if not maxnumber:
            maxnumber = "5" #Default to 5 when not provided
            
        return [SlotSet('SLOT_ENT_Max_Frequency_Number', maxnumber)]

class ActionFrequentlyPlacedOrders(Action):

    def name(self):
        return "action_frequently_placed_orders"

    def run(self, dispatcher, tracker, domain):

        frequency = next(tracker.get_latest_entity_values('ENT_Frequency'), None)

        if not frequency:
            dispatcher.utter_template('utter_wrong_Trade_ENT_Frequency', tracker)
            dispatcher.utter_template('utter_ask_Trade_ENT_Frequency', tracker)
            frequency = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        elif frequency.lower() not in ["top","bottom","most","least"]:
            dispatcher.utter_template('utter_wrong_ENT_Frequency', tracker)
            dispatcher.utter_template('utter_ask_ENT_Frequency', tracker)
            frequency = None
            return [UserUtteranceReverted()] # go back a turn in the conversation

        #Give a database call to fetch the informaiton before returning
        if frequency:
            # Make an API Call based on frquncy and Max Number set in a slot SLOT_ENT_Max_Frequency_Number
            data_from_api_call = "Security Name: No of trades \n Apple : 9232 \n IBM : 5253 \n Netflix : 3452 \n Facebook : 456 \n Microsoft : 145 \n"
            utr_text = "Here are the details that you requested\n" + data_from_api_call
            dispatcher.utter_message(utr_text)
            dispatcher.utter_template('utter_trades_bar_chart', tracker) 
        else:
             dispatcher.utter_template('utter_DefaultContact', tracker)         
        
        return [SlotSet('ENT_Frequency', frequency)]

class FetchProfileAction(Action):
    def name(self):
        return "action_fetch_profile"

    @staticmethod
    def date_by_adding_business_days(from_date, add_days):
		# type: () -> date
        """Evaluates the 3rd business date"""
        business_days_to_add = add_days
        current_date = from_date
        while business_days_to_add > 0:
            current_date += datetime.timedelta(days=1)
            weekday = current_date.weekday()
            if weekday >= 5: # sunday = 6
                continue
            business_days_to_add -= 1
        return current_date
		
    def run(self, dispatcher, tracker, domain):
        #  Fethc initial profile data with the API call. e.g. data = requests.get(url).json
        TradeDate = datetime.datetime.today()
        SettlementDate = self.date_by_adding_business_days(TradeDate,2)
        return [SlotSet("ENT_AccountNumber","983527"),SlotSet("ENT_Portfolio","Capital Portfolio - SMA"),SlotSet("ENT_TradeDate",TradeDate.strftime('%m-%d-%Y')),SlotSet("ENT_SettlementDate",SettlementDate.strftime('%m-%d-%Y'))]

class ActionStoreLimitPrice(Action):
    """Stores the Limit Price in a slot"""

    def name(self):
        return "action_store_limit_price"

    @staticmethod
    def is_float(string: Text) -> bool:
        """Check if a string is an integer"""
        try:
            float(string.replace(',', ''))
            return True
        except ValueError:
            return False

    def run(self, dispatcher, tracker, domain):
        Limit_Price = next(tracker.get_latest_entity_values('ENT_Number'), None)
        if not Limit_Price:
            dispatcher.utter_template('utter_wrong_SLOT_ENT_Limit_Price', tracker)
            dispatcher.utter_template('utter_ask_SLOT_ENT_Limit_Price', tracker)
            Limit_Price = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        if not self.is_float(Limit_Price) or float(Limit_Price.replace(',', '')) <= 0:
            dispatcher.utter_template('utter_wrong_SLOT_ENT_Limit_Price', tracker)
            dispatcher.utter_template('utter_ask_SLOT_ENT_Limit_Price', tracker)            
            # validation failed, set slot to None
            Limit_Price = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        return [SlotSet('SLOT_ENT_Limit_Price', Limit_Price.replace(',', ''))]

class ActionStoreStopPrice(Action):
    """Stores the Stop Price in a slot"""

    def name(self):
        return "action_store_stop_price"

    @staticmethod
    def is_float(string: Text) -> bool:
        """Check if a string is an integer"""
        try:
            float(string.replace(',', ''))
            return True
        except ValueError:
            return False

    def run(self, dispatcher, tracker, domain):
        Stop_Price = next(tracker.get_latest_entity_values('ENT_Number'), None)
        if not Stop_Price:
            dispatcher.utter_template('utter_wrong_SLOT_ENT_Stop_Price', tracker)
            dispatcher.utter_template('utter_ask_SLOT_ENT_Stop_Price', tracker)
            Stop_Price = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        if not self.is_float(Stop_Price) or float(Stop_Price.replace(',', '')) <= 0:
            dispatcher.utter_template('utter_wrong_SLOT_ENT_Stop_Price', tracker)
            dispatcher.utter_template('utter_ask_SLOT_ENT_Stop_Price', tracker)            
            # validation failed, set slot to None
            Stop_Price = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        return [SlotSet('SLOT_ENT_Stop_Price', Stop_Price.replace(',', ''))]

class ActionStoreOrderQuantity(Action):
    """Stores the Limit Price in a slot"""

    def name(self):
        return "action_store_order_quantity"

    @staticmethod
    def is_int(string: Text) -> bool:
        """Check if a string is an integer"""
        try:
            int(string.replace(',', ''))
            return True
        except ValueError:
            return False

    def run(self, dispatcher, tracker, domain):
        Order_quantity = next(tracker.get_latest_entity_values('ENT_Number'), None)
        #currency = next(tracker.get_latest_entity_values('ENT_Currency'), None)
        
        if not Order_quantity: #or currency
            dispatcher.utter_template('utter_wrong_SLOT_ENT_Order_Quantity', tracker)
            dispatcher.utter_template('utter_ask_SLOT_ENT_Order_Quantity', tracker)            
            Order_quantity = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        elif not self.is_int(Order_quantity) or int(Order_quantity.replace(',', '')) <= 0:
            dispatcher.utter_template('utter_wrong_SLOT_ENT_Order_Quantity', tracker)
            dispatcher.utter_template('utter_ask_SLOT_ENT_Order_Quantity', tracker) 
            # validation failed, set slot to None
            Order_quantity = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        return [SlotSet('SLOT_ENT_Order_Quantity', Order_quantity.replace(',', ''))]

class ActionStoreGoodTillDate(Action):
    """Stores the Date in a slot"""

    def name(self):
        return "action_store_goodtilldate"

    def run(self, dispatcher, tracker, domain):
        date = next(tracker.get_latest_entity_values('ENT_Date'), None)
        if not date:
            dispatcher.utter_template('utter_wrong_SLOT_ENT_GoodTillDate', tracker)
            dispatcher.utter_template('utter_ask_SLOT_ENT_GoodTillDate', tracker)
            date = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        return [SlotSet('SLOT_ENT_GoodTillDate', date)]

class ActionStoreCurrency(Action):
    """Stores the Currency in a slot"""

    def name(self):
        return "action_store_currency"

    @staticmethod
    def currency_db():
		# type: () -> List[Text]
        """Database of supported Securities - ENTER IN LOWER CASE ONLY!!"""
        return ["$","usd", "inr", "eur", "euro"]

    def run(self, dispatcher, tracker, domain):
        currency = next(tracker.get_latest_entity_values('ENT_Currency'), None)
        if not currency:
            dispatcher.utter_template('utter_wrong_ENT_Currency', tracker)
            dispatcher.utter_template('utter_ask_ENT_Currency', tracker)
            currency = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        elif currency.lower() not in self.currency_db():
            dispatcher.utter_template('utter_wrong_ENT_Currency', tracker)
            dispatcher.utter_template('utter_ask_ENT_Currency', tracker)
            # validation failed, set slot to None
            currency = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        return [SlotSet('ENT_Currency', currency.upper())]

class ActionStoreSecurityName(Action):
    """Stores the Limit Price in a slot"""

    def name(self):
        return "action_store_security_name"

    @staticmethod
    def security_db():
		# type: () -> List[Text]
        """Database of supported Securities - ENTER IN LOWER CASE ONLY!!"""
        SecuritiesList = []
        with open('./data/Finance_data/companyticker.txt') as txtfile:
            for line in txtfile:
                line = line.strip()
                line = line.lower()
                SecuritiesList.append(line)
        
        customlist = ["ibm", "coke", "apple", "microsoft", "facebook", "google",
				"amazon", "netflix", "ey", "oracle", "tesla", "prudential sigma mutual fund", "hack", "daimler", "bayer", "uber",
				"vodafone", "sap","ge"]
        SecuritiesList += customlist   
        return SecuritiesList

    @staticmethod
    def is_security(security,security_db):
        """Return False if security name is present in the list (substring)"""
        Result = [s for s in security_db if security.lower() in s.lower()]
#        print (Result)
        if Result:
            return False
        else:
            return True

    @staticmethod
    def find_security_price(Security_name):
        """Return current price of the security"""
        symbolList = []
        with open('./data/Finance_data/TickerMapping.csv') as csvfile:
            reader = csv.reader(csvfile)
            for line in reader:
                symbolList.append(line)
              
        ticker = None
        for s in symbolList:
            if Security_name.lower() == s[0].lower():
                ticker = str(s[0])
        if ticker == None:
            for s in symbolList:
                if Security_name.lower() in s[1].lower():
                    ticker = str(s[0])
                    break
        
        try:
            secuity_price = round(si.get_live_price(ticker),2)
        except:
            secuity_price = 0.0  # No data

        return secuity_price

    def run(self, dispatcher, tracker, domain):
        Security_name = next(tracker.get_latest_entity_values('ENT_Security_Name'), None)
        if not Security_name:
            dispatcher.utter_template('utter_wrong_ENT_Security_Name', tracker)
            dispatcher.utter_template('utter_ask_ENT_Security_Name', tracker)
            Security_name = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        elif self.is_security(Security_name,self.security_db()):
            #Security_name.lower() not in self.security_db()  .... older way
            dispatcher.utter_template('utter_wrong_ENT_Security_Name', tracker)
            dispatcher.utter_template('utter_ask_ENT_Security_Name', tracker)
            # validation failed, set slot to None
            Security_name = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        
        secuity_price = self.find_security_price(Security_name)

        return [SlotSet('ENT_Security_Name', Security_name.upper()), SlotSet('SLOT_ENT_Secutiy_Price', secuity_price)]
        #ActionExecuted(action_name=ACTION_LISTEN_NAME) Replcae action with action listen

class ActionStoreOrderType(Action):
    """Stores the Limit Price in a slot"""

    def name(self):
        return "action_store_order_type"

    @staticmethod
    def Order_type_db():
		# type: () -> List[Text]
        """Database - ENTER IN LOWER CASE ONLY!!"""
        return ["market", "limit", "stop limit", "stop loss"]

    def run(self, dispatcher, tracker, domain):
        order_type = next(tracker.get_latest_entity_values('ENT_Order_Type'), None)
        if not order_type:
            dispatcher.utter_template('utter_wrong_ENT_Order_Type', tracker)
            dispatcher.utter_template('utter_ask_ENT_Order_Type', tracker)
            order_type = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        elif order_type.lower() not in self.Order_type_db():
            dispatcher.utter_template('utter_wrong_ENT_Order_Type', tracker)
            dispatcher.utter_template('utter_ask_ENT_Order_Type', tracker)
            # validation failed, set slot to None
            order_type = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        return [SlotSet('ENT_Order_Type', order_type)]
        #ActionExecuted(action_name=ACTION_LISTEN_NAME) Replcae action with action listen

class ActionStoreTimeInForce(Action):
    """Stores the Limit Price in a slot"""

    def name(self):
        return "action_store_timeinforce"

    @staticmethod
    def timeinforce_db():
		# type: () -> List[Text]
        """Database  - ENTER IN LOWER CASE ONLY!!"""
        return ["good for the day", "good till cancelled", "good till date"]

    def run(self, dispatcher, tracker, domain):
        timeinforce = next(tracker.get_latest_entity_values('ENT_TimeInForce'), None)
        if not timeinforce:
            dispatcher.utter_template('utter_wrong_ENT_TimeInForce', tracker)
            dispatcher.utter_template('utter_ask_ENT_TimeInForce', tracker)
            timeinforce = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        elif timeinforce.lower() not in self.timeinforce_db():
            dispatcher.utter_template('utter_wrong_ENT_TimeInForce', tracker)
            dispatcher.utter_template('utter_ask_ENT_TimeInForce', tracker)
            # validation failed, set slot to None
            timeinforce = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        return [SlotSet('ENT_TimeInForce', timeinforce)]

class ActionUINavigation(Action):

    def name(self):
        return "action_ui_navigation"

    def run(self, dispatcher, tracker, domain):

        UIName = next(tracker.get_latest_entity_values('ENT_UI_Name'), None)

        if not UIName:
            dispatcher.utter_template('utter_wrong_ENT_UI_Name', tracker)
            dispatcher.utter_template('utter_ask_ENT_UI_Name', tracker)
            UIName = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        elif UIName.lower() not in ["fx","dashboard","candlesticks","candlesick","homepage"]:
            dispatcher.utter_template('utter_wrong_ENT_UI_Name', tracker)
            dispatcher.utter_template('utter_ask_ENT_UI_Name', tracker)
            UIName = None
            return [UserUtteranceReverted()] # go back a turn in the conversation

        #Give a database call to fetch the informaiton before returning
        if UIName.lower() == 'fx':
            dispatcher.utter_template('utter_ui_navigation_link_fx', tracker)
        elif UIName.lower() == 'dashboard':
            dispatcher.utter_template('utter_ui_navigation_link_dashboard', tracker)
        elif UIName.lower() == 'homepage':
            dispatcher.utter_template('utter_ui_navigation_link_homepage', tracker)    
        elif UIName.lower() == 'candlesticks' or UIName.lower() == 'candlesick':
            dispatcher.utter_template('utter_ui_navigation_link_candlesticks', tracker)
        
        return [SlotSet('ENT_UI_Name', UIName)]


class ActionAllMarketInfo(Action):

    def name(self):
        return "action_all_market_info"

    @staticmethod
    def render_mpl_table(data, img_type="default", randNum="100", col_width=3.0, row_height=0.3, font_size=11,
                         header_color='#40466e', row_colors=['#f1f1f2', 'w'], edge_color='w',
                         bbox=[0, 0, 1, 1], header_columns=0,
                         ax=None, **kwargs):
        if ax is None:
            size = (np.array(data.shape[::-1]) + np.array([0, 1])) * np.array([col_width, row_height])
            fig, ax = plt.subplots(figsize=size)
            ax.axis('off')
    
        mpl_table = ax.table(cellText=data.values, bbox=bbox, colLabels=data.columns, **kwargs, cellLoc='center', rowLoc='center', colLoc='center', loc='center')
    
        mpl_table.auto_set_font_size(False)
        mpl_table.set_fontsize(font_size)
    
        for k, cell in  six.iteritems(mpl_table._cells):
            cell.set_edgecolor(edge_color)

            try:
                cellText = cell.get_text().get_text()
                if '%' in cellText:
                    cellText=cellText.strip('%')
                if float(cellText) < 0.0:
                    cell._text.set_color('red')
                if float(cellText) > 0.0:
                    cell._text.set_color('green')                    
            except ValueError:
                pass
            
            if k[0] == 0 or k[1] < header_columns:
                cell.set_text_props(weight='bold', color='w')
                cell.set_facecolor(header_color)
            else:
                cell.set_facecolor(row_colors[k[0]%len(row_colors) ])
        
        fig = plt.gcf()
        fig.savefig('./static/images/CreatedImages/Pictures_'+img_type+randNum+'.png', dpi=100, bbox_inches='tight')
       
        return ax

    def run(self, dispatcher, tracker, domain):
        
        randNum = str(randint(1, 1000000)) #generate random number for images to display
        
        try:
            Indicecs_table = pd.read_html("https://finance.yahoo.com/world-indices")
            #Indicecs_table_txt = Indicecs_table[0].iloc[:,[1,2,3,4]].head().to_string()
            Indicecs_table_txt = "../static/images/CreatedImages/Pictures_Indices"+randNum+".png"
            
            df = Indicecs_table[0].iloc[:9,[1,2,4]] # removed 3,  .head()
            self.render_mpl_table(df, img_type="Indices", randNum=randNum, header_columns=0, col_width=3.5)
            
        except:
            Indicecs_table_txt = 'There is no Indices data available right now'
        
        try:
            SecTables = pd.read_html("https://eresearch.fidelity.com/eresearch/goto/markets_sectors/landing.jhtml")
            SectorTable = SecTables[4].iloc[:11,[0,2]]
            SectorTable.columns = ['Sectors', 'Last % Change']
            #SecTables_txt = SectorTable.to_string()    
            SecTables_txt = "../static/images/CreatedImages/Pictures_Sector"+randNum+".png"
            
            self.render_mpl_table(SectorTable, img_type="Sector", randNum=randNum, header_columns=0, col_width=4)
        except:
            SecTables_txt = 'There is no Sector data available right now'            
        
        #utr_text = "Indices Info:\n " + Indicecs_table_txt + " \n Sectors Movement:\n" + SecTables_txt
        #dispatcher.utter_message(utr_text)
        dispatcher.utter_message("Indices Info:")
        dispatcher.utter_message(Indicecs_table_txt)
        dispatcher.utter_message("Sectors Movement:")
        dispatcher.utter_message(SecTables_txt)

        return []

class ActionActiveStockInfo(Action):

    def name(self):
        return "action_active_stock_info"

    @staticmethod
    def render_mpl_table(data, img_type="default", randNum="100", col_width=3.0, row_height=0.3, font_size=11,
                         header_color='#40466e', row_colors=['#f1f1f2', 'w'], edge_color='w',
                         bbox=[0, 0, 1, 1], header_columns=0,
                         ax=None, **kwargs):
        if ax is None:
            size = (np.array(data.shape[::-1]) + np.array([0, 1])) * np.array([col_width, row_height])
            fig, ax = plt.subplots(figsize=size)
            ax.axis('off')
    
        mpl_table = ax.table(cellText=data.values, bbox=bbox, colLabels=data.columns, **kwargs, cellLoc='center', rowLoc='center', colLoc='center', loc='center')
    
        mpl_table.auto_set_font_size(False)
        mpl_table.set_fontsize(font_size)
    
        for k, cell in  six.iteritems(mpl_table._cells):
            cell.set_edgecolor(edge_color)

            try:
                cellText = cell.get_text().get_text()
                if '%' in cellText:
                    cellText=cellText.strip('%')
                if float(cellText) < 0.0:
                    cell._text.set_color('red')
                if float(cellText) > 0.0:
                    cell._text.set_color('green')                      
            except ValueError:
                pass
            
            if k[0] == 0 or k[1] < header_columns:
                cell.set_text_props(weight='bold', color='w')
                cell.set_facecolor(header_color)
            else:
                cell.set_facecolor(row_colors[k[0]%len(row_colors) ])
        
        fig = plt.gcf()
        fig.savefig('./static/images/CreatedImages/Pictures_'+img_type+randNum+'.png', dpi=100, bbox_inches='tight')
       
        return ax

    def run(self, dispatcher, tracker, domain):
        
        randNum = str(randint(1, 1000000)) #generate random number for images to display, To handle Chrome cashing issue.
        
        try:
            Active_stock_table = pd.read_html("https://finance.yahoo.com/most-active")
            Active_stock_table_txt = "../static/images/CreatedImages/Pictures_ActiveStocks"+randNum+".png"
            
            df = Active_stock_table[0].iloc[:10,[0,2,3,4]]
            self.render_mpl_table(df, img_type="ActiveStocks", randNum=randNum, header_columns=0, col_width=2.0)
            
        except:
            Active_stock_table_txt = 'There is no Active stock data available right now'


        dispatcher.utter_message("Active Stocks:")
        dispatcher.utter_message(Active_stock_table_txt)

        return []

class ActionGainerStockInfo(Action):

    def name(self):
        return "action_gainer_stock_info"

    @staticmethod
    def render_mpl_table(data, img_type="default", randNum="100", col_width=3.0, row_height=0.3, font_size=11,
                         header_color='#40466e', row_colors=['#f1f1f2', 'w'], edge_color='w',
                         bbox=[0, 0, 1, 1], header_columns=0,
                         ax=None, **kwargs):
        if ax is None:
            size = (np.array(data.shape[::-1]) + np.array([0, 1])) * np.array([col_width, row_height])
            fig, ax = plt.subplots(figsize=size)
            ax.axis('off')
    
        mpl_table = ax.table(cellText=data.values, bbox=bbox, colLabels=data.columns, **kwargs, cellLoc='center', rowLoc='center', colLoc='center', loc='center')
    
        mpl_table.auto_set_font_size(False)
        mpl_table.set_fontsize(font_size)
    
        for k, cell in  six.iteritems(mpl_table._cells):
            cell.set_edgecolor(edge_color)

            try:
                cellText = cell.get_text().get_text()
                if '%' in cellText:
                    cellText=cellText.strip('%')
                if float(cellText) < 0.0:
                    cell._text.set_color('red')
                if float(cellText) > 0.0:
                    cell._text.set_color('green')                      
            except ValueError:
                pass
            
            if k[0] == 0 or k[1] < header_columns:
                cell.set_text_props(weight='bold', color='w')
                cell.set_facecolor(header_color)
            else:
                cell.set_facecolor(row_colors[k[0]%len(row_colors) ])
        
        fig = plt.gcf()
        fig.savefig('./static/images/CreatedImages/Pictures_'+img_type+randNum+'.png', dpi=100, bbox_inches='tight')
       
        return ax

    def run(self, dispatcher, tracker, domain):
        
        randNum = str(randint(1, 1000000)) #generate random number for images to display, To handle Chrome cashing issue.
        
        try:
            Gainer_stock_table = pd.read_html("https://finance.yahoo.com/gainers")
            Gainer_stock_table_txt = "../static/images/CreatedImages/Pictures_GainerStocks"+randNum+".png"
            
            df = Gainer_stock_table[0].iloc[:10,[0,2,3,4]]
            self.render_mpl_table(df, img_type="GainerStocks", randNum=randNum, header_columns=0, col_width=2.0)
            
        except:
            Gainer_stock_table_txt = 'There is no Market Gainer stock data available right now'


        dispatcher.utter_message("Market Gainer Stocks:")
        dispatcher.utter_message(Gainer_stock_table_txt)

        return []

class ActionLoserStockInfo(Action):

    def name(self):
        return "action_loser_stock_info"

    @staticmethod
    def render_mpl_table(data, img_type="default", randNum="100", col_width=3.0, row_height=0.3, font_size=11,
                         header_color='#40466e', row_colors=['#f1f1f2', 'w'], edge_color='w',
                         bbox=[0, 0, 1, 1], header_columns=0,
                         ax=None, **kwargs):
        if ax is None:
            size = (np.array(data.shape[::-1]) + np.array([0, 1])) * np.array([col_width, row_height])
            fig, ax = plt.subplots(figsize=size)
            ax.axis('off')
    
        mpl_table = ax.table(cellText=data.values, bbox=bbox, colLabels=data.columns, **kwargs, cellLoc='center', rowLoc='center', colLoc='center', loc='center')
    
        mpl_table.auto_set_font_size(False)
        mpl_table.set_fontsize(font_size)
    
        for k, cell in  six.iteritems(mpl_table._cells):
            cell.set_edgecolor(edge_color)

            try:
                cellText = cell.get_text().get_text()
                if '%' in cellText:
                    cellText=cellText.strip('%')
                if float(cellText) < 0.0:
                    cell._text.set_color('red')
                if float(cellText) > 0.0:
                    cell._text.set_color('green')                      
            except ValueError:
                pass
            
            if k[0] == 0 or k[1] < header_columns:
                cell.set_text_props(weight='bold', color='w')
                cell.set_facecolor(header_color)
            else:
                cell.set_facecolor(row_colors[k[0]%len(row_colors) ])
        
        fig = plt.gcf()
        fig.savefig('./static/images/CreatedImages/Pictures_'+img_type+randNum+'.png', dpi=100, bbox_inches='tight')
       
        return ax

    def run(self, dispatcher, tracker, domain):
        
        randNum = str(randint(1, 1000000)) #generate random number for images to display, To handle Chrome cashing issue.
        
        try:
            Loser_stock_table = pd.read_html("https://finance.yahoo.com/losers")
            Loser_stock_table_txt = "../static/images/CreatedImages/Pictures_LoserStocks"+randNum+".png"
            
            df = Loser_stock_table[0].iloc[:10,[0,2,3,4]]
            self.render_mpl_table(df, img_type="LoserStocks", randNum=randNum, header_columns=0, col_width=2.0)
            
        except:
            Loser_stock_table_txt = 'There is no Market Loser stock data available right now'


        dispatcher.utter_message("Market Loser Stocks:")
        dispatcher.utter_message(Loser_stock_table_txt)

        return []


class ActionSecurityRating(Action):

    def name(self):
        return "action_market_security_rating"

    @staticmethod
    def render_mpl_table(data, img_type="default", randNum="100", col_width=3.0, row_height=0.3, font_size=11,
                         header_color='#40466e', row_colors=['#f1f1f2', 'w'], edge_color='w',
                         bbox=[0, 0, 1, 1], header_columns=0,
                         ax=None, **kwargs):
        if ax is None:
            size = (np.array(data.shape[::-1]) + np.array([0, 1])) * np.array([col_width, row_height])
            fig, ax = plt.subplots(figsize=size)
            ax.axis('off')
    
        mpl_table = ax.table(cellText=data.values, bbox=bbox, colLabels=data.columns, **kwargs, cellLoc='center', rowLoc='center', colLoc='center', loc='center')
    
        mpl_table.auto_set_font_size(False)
        mpl_table.set_fontsize(font_size)
    
        for k, cell in  six.iteritems(mpl_table._cells):
            cell.set_edgecolor(edge_color)

#            try:
#                cellText = cell.get_text().get_text()
#                if '%' in cellText:
#                    cellText=cellText.strip('%')
#                if float(cellText) < 0.0:
#                    cell._text.set_color('red')
#                if float(cellText) > 0.0:
#                    cell._text.set_color('green')                      
#            except ValueError:
#                pass
            
            if k[0] == 0 or k[1] < header_columns:
                cell.set_text_props(weight='bold', color='w')
                cell.set_facecolor(header_color)
            else:
                cell.set_facecolor(row_colors[k[0]%len(row_colors) ])
        
        fig = plt.gcf()
        fig.savefig('./static/images/CreatedImages/Pictures_'+img_type+randNum+'.png', dpi=100, bbox_inches='tight')
       
        return ax

    @staticmethod
    def find_security_ticker(Security_name):
        """Return security ticker and price"""
        symbolList = []
        with open('./data/Finance_data/TickerMapping.csv') as csvfile:
            reader = csv.reader(csvfile)
            for line in reader:
                symbolList.append(line)
              
        ticker = None
        for s in symbolList:
            if Security_name.lower() == s[0].lower():
                ticker = str(s[0])
        if ticker == None:
            for s in symbolList:
                if Security_name.lower() in s[1].lower():
                    ticker = str(s[0])
                    break

        try:
            secuity_price = round(si.get_live_price(ticker),2)
        except:
            secuity_price = 0.0  # No data					
					
        return ticker, secuity_price

    def run(self, dispatcher, tracker, domain):
        
        randNum = str(randint(1, 1000000)) #generate random number for images to display, To handle Chrome cashing issue.
        df = None
        try:
            Security_name = tracker.get_slot('ENT_Security_Name')
            TodaysDate = tracker.get_slot('ENT_TradeDate')
            ticker, secuity_price = self.find_security_ticker(Security_name)

            header = {
              "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36",
              "X-Requested-With": "XMLHttpRequest"
            }
            url = "https://www.marketbeat.com/stocks/NASDAQ/"+ ticker +"/price-target/"
            r = requests.get(url, headers=header)
            
            Security_rating_table = pd.read_html(r.text)
            Security_rating_table_txt = "../static/images/CreatedImages/Pictures_StockRatings"+randNum+".png"
            
            df = Security_rating_table[0].iloc[[0,1,3,4],[0,1,2,3]]
            df.rename({"Unnamed: 0":""}, axis="columns", inplace=True) # remove "Unnamed: 0" from first column

            #Data Processing
            df.rename({"Today":"ABCfund"}, axis="columns", inplace=True)
            df.rename({"30 Days Ago":"DEFfund"}, axis="columns", inplace=True)
            df.rename({"90 Days Ago":"XYZfund"}, axis="columns", inplace=True)
            df.loc[df[''] == "Consensus Rating:", ''] = "Conviction Rating"  # Replace Row value
            df.loc[df[''] == "Consensus Rating Score:", ''] = "Rating Score"  # Replace Row value
            df.loc[df[''] == "Consensus Price Target:", ''] = "Price Target"  # Replace Row value
            df.loc[df[''] == "Price Target Upside:", ''] = "Target Upside"  # Replace Row value

            self.render_mpl_table(df, img_type="StockRatings", randNum=randNum, header_columns=0, col_width=1.8)

        except IndexError: #try NYSE if ticker is not on NASDAQ
            url = "https://www.marketbeat.com/stocks/NYSE/"+ ticker +"/price-target/"
            r = requests.get(url, headers=header)
            
            Security_rating_table = pd.read_html(r.text)
            Security_rating_table_txt = "../static/images/CreatedImages/Pictures_StockRatings"+randNum+".png"
            
            df = Security_rating_table[0].iloc[[0,1,3,4],[0,1,2,3]]
            df.rename({"Unnamed: 0":""}, axis="columns", inplace=True) # remove "Unnamed: 0" from first column

            #Data Processing
            df.rename({"Today":"ABCfund"}, axis="columns", inplace=True)
            df.rename({"30 Days Ago":"DEFfund"}, axis="columns", inplace=True)
            df.rename({"90 Days Ago":"XYZfund"}, axis="columns", inplace=True)
            df.loc[df[''] == "Consensus Rating:", ''] = "Conviction Rating"  # Replace Row value
            df.loc[df[''] == "Consensus Rating Score:", ''] = "Rating Score"  # Replace Row value
            df.loc[df[''] == "Consensus Price Target:", ''] = "Price Target"  # Replace Row value
            df.loc[df[''] == "Price Target Upside:", ''] = "Target Upside"  # Replace Row value



            self.render_mpl_table(df, img_type="StockRatings", randNum=randNum, header_columns=0, col_width=1.8)

        except:
            Security_rating_table_txt = 'There is no security rating available right now'

        if df is None or "Sector" in list(df):
            dispatcher.utter_message("No rating information is available right now.")
        else:
            dispatcher.utter_message("On "+TodaysDate+", below is the security rating information for "+ticker+". Current Market price is $"+str(secuity_price)+".") #You can get further details on https://www.marketbeat.com
            dispatcher.utter_message(Security_rating_table_txt)

        return []



class ActionShowTradeBreaks(Action):

    def name(self):
        return "action_show_trade_breaks"

    @staticmethod
    def render_mpl_table(data, img_type="default", randNum="100", col_width=3.0, row_height=0.3, font_size=11,
                         header_color='#40466e', row_colors=['#f1f1f2', 'w'], edge_color='w',
                         bbox=[0, 0, 1, 1], header_columns=0,
                         ax=None, **kwargs):
        if ax is None:
            size = (np.array(data.shape[::-1]) + np.array([0, 1])) * np.array([col_width, row_height])
            fig, ax = plt.subplots(figsize=size)
            ax.axis('off')
    
        mpl_table = ax.table(cellText=data.values, bbox=bbox, colLabels=data.columns, **kwargs, cellLoc='center', rowLoc='center', colLoc='center', loc='center')
    
        mpl_table.auto_set_font_size(False)
        mpl_table.set_fontsize(font_size)
    
        for k, cell in six.iteritems(mpl_table._cells):  #k[0] and k[1] are x and y coordinates
            cell.set_edgecolor(edge_color)

            try:
                cellText = cell.get_text().get_text()
                if '%' in cellText:
                    cellText=cellText.strip('%')
                #if float(cellText) < 0.0:
                 #   cell._text.set_color('red')
                if float(cellText) > 0.0:
                    cell._text.set_color('green')

                #Hardoding for demo....should be removed....K[1] is column, k[0] is row
                if k[1] == 5 and k[0] == 1:
                    cell._text.set_color('red')
                if k[1] == 8 and k[0] == 1:
                    cell._text.set_color('red')
                if k[1] == 6 and k[0] == 2:
                    cell._text.set_color('red')
                if k[1] == 9 and k[0] == 2:
                    cell._text.set_color('red')
                if k[1] == 4 and k[0] == 3:
                    cell._text.set_color('red')
                if k[1] == 7 and k[0] == 3:
                    cell._text.set_color('red')
                if k[1] == 6 and k[0] == 3:
                    cell._text.set_color('red')
                if k[1] == 9 and k[0] == 3:
                    cell._text.set_color('red')
                if k[1] == 5 and k[0] == 4:
                    cell._text.set_color('red')
                if k[1] == 8 and k[0] == 4:
                    cell._text.set_color('red')


            except ValueError:
                pass
            
            if k[0] == 0 or k[1] < header_columns:
                cell.set_text_props(weight='bold', color='w')
                cell.set_facecolor(header_color)
            else:
                cell.set_facecolor(row_colors[k[0]%len(row_colors)])
        
        fig = plt.gcf()
        fig.savefig('./static/images/CreatedImages/Pictures_'+img_type+randNum+'.png', dpi=100, bbox_inches='tight')
       
        return ax

    def run(self, dispatcher, tracker, domain):

        randNum = str(randint(1, 1000000)) #generate random number for images to display, To handle Chrome cashing issue.
        try:
            Trade_Breaks_Info = pd.read_csv("./data/database/tradebreaks.csv", header=0, encoding='utf-8')
            Trade_Breaks_txt = "../static/images/CreatedImages/Pictures_TradeBreaks"+randNum+".png"

            df = Trade_Breaks_Info.loc[Trade_Breaks_Info['Break'] == "Y"]  # Only show those rows having breaks marked as Yes
            df = df.drop('Break',1)
            TradeDate = datetime.datetime.today()
            df.loc[df['Date'] == "Today", 'Date'] = TradeDate.strftime('%m-%d-%Y') # Replace "Today" from the spreadhseet to actual date
            df.loc[df['Date'] == "Today", 'Date'] = TradeDate.strftime('%m-%d-%Y')
            TradeDate = TradeDate + datetime.timedelta(days=-1)
            df.loc[df['Date'] == "Today-1", 'Date'] = TradeDate.strftime('%m-%d-%Y')
            TradeDate = TradeDate + datetime.timedelta(days=-2)
            df.loc[df['Date'] == "Today-2", 'Date'] = TradeDate.strftime('%m-%d-%Y')

            self.render_mpl_table(df, img_type="TradeBreaks", randNum=randNum, header_columns=0, col_width=1.2)

        except:
            Trade_Breaks_txt = 'There is no Trade Break information available right now'

        dispatcher.utter_message("Trade Breaks:")
        dispatcher.utter_message(Trade_Breaks_txt)

        if "/static/images" in Trade_Breaks_txt:   # If there are Tread Breaks, show below option
            message = "Do you want to fix the trade break? If yes, select the 'trade number', else select 'No'"
            buttons = [{'title': 'No',
                        'payload': '/enter_data{"ENT_Number": "0"}'}]

            for num in df.iloc[:, 0]:
                buttons.append({'title': str(num),'payload': '/enter_data{"ENT_AlphaNumeric":"'+str(num)+'"}'})
            dispatcher.utter_button_message(message, buttons=buttons)
        else:
            dispatcher.utter_template('utter_faq_confirmation', tracker)

        return []


class ActionStoreTradeNumber(Action):
    """Stores the Limit Price in a slot"""

    def name(self):
        return "action_store_trade_number"

    def run(self, dispatcher, tracker, domain):
        trade_number = next(tracker.get_latest_entity_values('ENT_AlphaNumeric'), None)

        if not trade_number:
            dispatcher.utter_template('utter_wrong_SLOT_ENT_Trade_Number', tracker)
            dispatcher.utter_template('utter_ask_SLOT_ENT_Trade_Number', tracker)
            trade_number = None
            return [UserUtteranceReverted()]  # go back a turn in the conversation

        if trade_number == "0" or trade_number is None:
            pass
        else:
            dispatcher.utter_template('utter_trade_break_value_to_accept', tracker)

        return [SlotSet('SLOT_ENT_Trade_Number', trade_number)]

class ActionFixTradeBreaks(Action):

    def name(self):
        return "action_fix_trade_breaks"

    def run(self, dispatcher, tracker, domain):
        TradeNumber = tracker.get_slot('SLOT_ENT_Trade_Number')
        action = next(tracker.get_latest_entity_values('ENT_Number'), None)

        if TradeNumber == "0" or TradeNumber is None:
            dispatcher.utter_template('utter_no_action_taken', tracker)
        else:
            try:
                Trade_Breaks_Info = pd.read_csv("./data/database/tradebreaks.csv")

                tradebreak_exists = None
                for num in Trade_Breaks_Info.iloc[:, 0]:  # If TradeNumber is not in excel or already with N indicator then message that no action needed or Nothing to act on
                    if num == TradeNumber:
                        if Trade_Breaks_Info.loc[Trade_Breaks_Info['Trd No'] == TradeNumber, 'Break'].iloc[0] == "Y": # Trade break exists
                            tradebreak_exists = "Yes"

                if tradebreak_exists:
                    Trade_Breaks_Info.loc[Trade_Breaks_Info['Trd No'] == TradeNumber, 'Break'] = 'N'
                    Trade_Breaks_Info.to_csv("./data/database/tradebreaks.csv", encoding='utf-8', index=False)
                    if action == "0":
                        Fix_Trade_Breaks_txt = 'Trade Break is resolved. Counterparty values are accepted for Trade number ' + TradeNumber
                    elif action == "1":
                        Fix_Trade_Breaks_txt = 'Trade Break is resolved. Your values are accepted for Trade number ' + TradeNumber
                    else:
                        Fix_Trade_Breaks_txt = 'Trade Break is resolved for Trade number ' + TradeNumber
                else:
                    Fix_Trade_Breaks_txt = 'Trade Break does not exist on Trade number ' + TradeNumber
            except:
                Fix_Trade_Breaks_txt = 'Trade Break could not be resolved. Please try later.'

            dispatcher.utter_message(Fix_Trade_Breaks_txt)

        return []

class ActionStoreFundName(Action):
    """Stores the Fund Name in a slot"""

    def name(self):
        return "action_store_fund_name"

    @staticmethod
    def Order_type_db():
		# type: () -> List[Text]
        """Database - ENTER IN LOWER CASE ONLY!!"""
        return ["abcfund", "abc fund", "xyz fund", "xyzfund", "deffund", "def fund", "alpha fund", "beta fund", "sde fund", "fund sde"]

    def run(self, dispatcher, tracker, domain):
        fund_name = next(tracker.get_latest_entity_values('ENT_Fund_Name'), None)
        if not fund_name:  #Check if slot already has a value
            fund_name = tracker.get_slot('SLOT_ENT_Fund_Name')

        if not fund_name:
            dispatcher.utter_template('utter_wrong_ENT_Fund_Name', tracker)
            dispatcher.utter_template('utter_ask_ENT_Fund_Name', tracker)
            fund_name = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        elif fund_name.lower() not in self.Order_type_db():
            dispatcher.utter_template('utter_wrong_ENT_Fund_Name', tracker)
            dispatcher.utter_template('utter_ask_ENT_Fund_Name', tracker)
            # validation failed, set slot to None
            fund_name = None
            return [UserUtteranceReverted()] # go back a turn in the conversation
        return [SlotSet('SLOT_ENT_Fund_Name', fund_name)]

