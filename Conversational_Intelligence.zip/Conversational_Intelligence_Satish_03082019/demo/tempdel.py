import logging

from rasa_core_sdk import Action
from rasa_core_sdk.events import SlotSet, UserUtteranceReverted, \
                                 ConversationPaused

from typing import Dict, Text, Any, List, Union
from rasa_core_sdk import ActionExecutionRejection
from rasa_core_sdk import Tracker
from rasa_core_sdk.executor import CollectingDispatcher
from rasa_core_sdk.forms import FormAction, REQUESTED_SLOT
import datetime
import csv
from yahoo_fin import stock_info as si
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import six
from random import randint
import requests

#
# def render_mpl_table(data, img_type="default", randNum="100", col_width=3.0, row_height=0.3, font_size=11,
#                      header_color='#40466e', row_colors=['#f1f1f2', 'w'], edge_color='w',
#                      bbox=[0, 0, 1, 1], header_columns=0,
#                      ax=None, **kwargs):
#     if ax is None:
#         size = (np.array(data.shape[::-1]) + np.array([0, 1])) * np.array([col_width, row_height])
#         fig, ax = plt.subplots(figsize=size)
#         ax.axis('off')
#
#     mpl_table = ax.table(cellText=data.values, bbox=bbox, colLabels=data.columns, **kwargs, cellLoc='center',
#                          rowLoc='center', colLoc='center', loc='center')
#
#     mpl_table.auto_set_font_size(False)
#     mpl_table.set_fontsize(font_size)
#
#     for k, cell in six.iteritems(mpl_table._cells):
#         cell.set_edgecolor(edge_color)
#
#         try:
#             cellText = cell.get_text().get_text()
#             if '%' in cellText:
#                 cellText = cellText.strip('%')
#             if float(cellText) < 0.0:
#                 cell._text.set_color('red')
#             if float(cellText) > 0.0:
#                 cell._text.set_color('green')
#         except ValueError:
#             pass
#
#         if k[0] == 0 or k[1] < header_columns:
#             cell.set_text_props(weight='bold', color='w')
#             cell.set_facecolor(header_color)
#         else:
#             cell.set_facecolor(row_colors[k[0] % len(row_colors)])
#
#     fig = plt.gcf()
#     fig.savefig('../static/images/CreatedImages/Pictures_' + img_type + randNum + '.png', dpi=100, bbox_inches='tight')
#
#     return ax
#
#
#
#
# randNum = str(randint(1, 1000000))
# try:
#     Trade_Breaks_Info = pd.read_csv("../data/database/tradebreaks.csv", header=0, encoding='utf-8')
#     Trade_Breaks_txt = "../static/images/CreatedImages/Pictures_TradeBreaks " +randNum +".png"
#
#     df = Trade_Breaks_Info.loc[Trade_Breaks_Info['Break'] == "Y"]  # Only show those rows having breaks marked
#     #df = Trade_Breaks_Info.loc[Trade_Breaks_Info.Break == "Y"]
#     render_mpl_table(df, img_type="TradeBreaks", randNum=randNum, header_columns=0, col_width=2.0)
#     print(Trade_Breaks_Info)
#     print(df)
# except:
#     Trade_Breaks_txt = 'There is no Trade Break information available right now'
#
# print(Trade_Breaks_txt)

Trade_Breaks_Info = pd.read_csv("../data/database/tradebreaks.csv", header=0, encoding='utf-8')

tradebreak_exists = None
for num in Trade_Breaks_Info.iloc[:,0]:  # If TradeNumber is not in excel or already with N indicator then message that no action needed or Nothing to act on
    if num == "T5342":
        if Trade_Breaks_Info.loc[Trade_Breaks_Info['Trd No'] == "T5342", 'Break'].iloc[0] == "Y":  # Trade break exists
            tradebreak_exists = "Yes"

print(tradebreak_exists)
