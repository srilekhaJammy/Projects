#from SimpleWebSocketServer import SimpleWebSocketServer, WebSocket
from flask import Flask, render_template, session
from flask_sockets import Sockets
import subprocess
import urllib.request
import urllib.parse
import requests
import json

# Simple WebSocket for single-user chat bot

app = Flask(__name__)
app.secret_key="Trying my best"
sockets = Sockets(app)

@sockets.route('/')
def handleMessage(ws):
    #session['productasinID'] = "default"
    data = {}
    while not ws.closed:
        # echo message back to client
        message = ws.receive()
        print(message)
        
        data['query'] = message
        url_values = urllib.parse.urlencode(data)
        url = 'http://localhost:5005/conversations/default/respond'+ '?' + url_values
        print("URL is:  ", url)
        json_response = requests.get(url).json()
        print("1 json_response")
        print (json_response)
      
        
        replyText= {}
        for m in json_response:
            if 'text' in m :
                if "../static/images" in str(m['text']) and "https" not in str(m['text']):
                    im = str(m['text'])
                    replyText['image'] = im                 
                else:    
                    response = str(m['text'])
                    replyText['text'] = response                    
#                    print("inside for >>>> this is m >>>>",str(m))
#                    print("inside loop response ")
#                    print (response)
            if 'buttons' in m :
                bt = m['buttons']
                print("there are buttons")
                print (bt)
                replyText['buttons'] = bt
            elif 'image' in m :
                im = m['image']
                replyText['image'] = im
                print (m['image'],replyText['image'])
            print ("replytext >>>>> ",replyText)
            ws.send(str(json.dumps(replyText)))
            replyText= {}
        print("Final Response sent")

def handleConnected():
    print(address, 'connected')

def handleClose():
    print(address, 'closed')

@app.route('/', methods=['GET'])
def hw():
    #session['productasinID'] = 'default'	
    return render_template('index.html')

if __name__ == "__main__":
    from gevent import pywsgi
    from geventwebsocket.handler import WebSocketHandler
    server = pywsgi.WSGIServer(('127.0.0.1', 9000), app, handler_class=WebSocketHandler)
    #server = pywsgi.WSGIServer(('127.0.0.1', 9000), app, handler_class=WebSocketHandler, keyfile='server.key', certfile='server.crt')
    print("Chatbot launched... Please open localhost:9000.  http://:9000")
    server.serve_forever()
    

# server = SimpleWebSocketServer('', 8000, ChatServer)
# server.serveforever()
