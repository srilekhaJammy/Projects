## For FAQs_SalesTeamContact
* INT_FAQ_CustomerSupportDetails{"ENT_Departments": "operations"}
    - action_fetch_profile
    - action_find_contact_department
    - slot{"ENT_Departments": "operations"}	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart
	
## For FAQ without entity
* INT_FAQ_CustomerSupportDetails
    - action_fetch_profile
    - action_find_contact_department
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

## For FAQs_SalesTeamContact - Deny
* INT_FAQ_CustomerSupportDetails{"ENT_Departments": "customer"}
    - action_fetch_profile
    - action_find_contact_department
    - slot{"ENT_Departments": "customer"}
    - utter_faq_confirmation
* deny
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
	- action_restart
    
## For FAQ without entity - Deny
* INT_FAQ_CustomerSupportDetails
    - action_fetch_profile
    - action_find_contact_department
    - utter_faq_confirmation
* deny
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
	- action_restart	

	
	
	
## For FAQ with API Order Info - Frequently traded - Happy Path
* INT_API_ask_OrderInfo{"ENT_Frequency": "top","ENT_Number":"5"}
	- action_fetch_profile
	- action_store_max_frequency_number
	- slot{"SLOT_ENT_Max_Frequency_Number":"5"}
    - action_frequently_placed_orders
	- slot{"ENT_Frequency": "top"}
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart
	
## For FAQ with API Order Info - Frequently traded without number
* INT_API_ask_OrderInfo{"ENT_Frequency": "top"}
	- action_fetch_profile
	- action_store_max_frequency_number
	- slot{"SLOT_ENT_Max_Frequency_Number":"5"}
    - action_frequently_placed_orders
	- slot{"ENT_Frequency": "top"}
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

## For FAQ with API Order Info - Without entities
* INT_API_ask_OrderInfo
	- action_fetch_profile
	- action_store_max_frequency_number
	- slot{"SLOT_ENT_Max_Frequency_Number":"5"}
    - action_frequently_placed_orders
	- slot{"ENT_Frequency": "top"}
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

## For FAQ with API Order Info - Frequently traded - Deny
* INT_API_ask_OrderInfo{"ENT_Frequency": "top","ENT_Number":"5"}
	- action_fetch_profile
	- action_store_max_frequency_number
	- slot{"SLOT_ENT_Max_Frequency_Number":"5"}
    - action_frequently_placed_orders
	- slot{"ENT_Frequency": "top"}
    - utter_faq_confirmation
* deny
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
	- action_restart	
	




	
## Buy transaction  - When user only gives Intent with no entities
* INT_API_BuySecurity
	- action_fetch_profile
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Market"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart

## Buy transaction  - When user only gives Intent with no entities - Limit followed by Good till Cancelled
* INT_API_BuySecurity
	- action_fetch_profile
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Limit"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}	
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good till Cancelled"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good till Cancelled"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	
	
## Buy transaction  - When user only gives Intent with no entities, deny at the end
* INT_API_BuySecurity
	- action_fetch_profile
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Market"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* deny
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
	- action_restart
	
## Buy transaction  - When user gives Intent with Security name as entity - Market
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Market"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart


## Buy transaction  - When user gives Intent with Security name as entity - Limit
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Limit"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}	
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	

	
## Buy transaction  - When user gives Intent with Security name and quantity as entities - Market
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Market"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	


## Buy transaction  - When user gives Intent with Security name and quantity as entities - Limit
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Limit"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	


## Buy transaction  - When user gives Intent with Security name and Limit Type as entities
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Order_Type": "Limit"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	
	

## Buy transaction  - When user gives Intent with Quantity as entity - Market
* INT_API_BuySecurity{"ENT_Number": "5342"}
	- action_fetch_profile
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "MSFT"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "MSFT"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Market"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart
	
## Buy transaction  - When user gives Intent with Quantity as entity - Limit
* INT_API_BuySecurity{"ENT_Number": "5342"}
	- action_fetch_profile
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "MSFT"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "MSFT"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Limit"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	
	
	
## Buy transaction  - When user gives Intent with Security name and Dollar Amount as entities - Market
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567", "ENT_Currency": "USD"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_currency
    - slot{"ENT_Currency": "USD"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Market"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	

	
## Buy transaction  - When user gives Intent with Dollar Amount as entities - Market
* INT_API_BuySecurity{"ENT_Number": "567", "ENT_Currency": "USD"}
	- action_fetch_profile
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_currency
    - slot{"ENT_Currency": "USD"}
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "MSFT"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "MSFT"}	
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Market"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	
	
	

## Buy transaction  - When user gives Intent with Security name and Dollar Amount as entities - Limit
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567", "ENT_Currency": "USD"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_currency
    - slot{"ENT_Currency": "USD"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Limit"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart		
	
	
## Buy transaction  - When user gives Intent with Security name, quantity, Order type as entities- Market
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567", "ENT_Order_Type": "Market"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart		


## Buy transaction  - When user gives Intent with Security name, quantity, Order type as entities - Limit
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567", "ENT_Order_Type": "Limit"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart


## Buy transaction  - When user gives Intent with Security name, quantity, Order type as entities- Market
* INT_API_BuySecurity{"ENT_Number": "567", "ENT_Order_Type": "Market"}
	- action_fetch_profile
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - slot{"ENT_TimeInForce": "Good for the day"}
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "MSFT"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "MSFT"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart


## Buy transaction  - When user gives Intent with Security name, quantity, Order type as entities - Limit
* INT_API_BuySecurity{"ENT_Number": "567", "ENT_Order_Type": "Limit"}
	- action_fetch_profile
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "MSFT"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "MSFT"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart
	
	
## Buy transaction  - When user gives Intent with Security name, quantity, Order type Stop Loss as entities
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567", "ENT_Order_Type": "Stop Loss"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "567"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Stop Loss"}
    - utter_ask_SLOT_ENT_Stop_Price
* enter_data{"ENT_Number": "768.5"}
    - action_store_stop_price
    - slot{"SLOT_ENT_Stop_Price": "768.5"}	
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	
	
## Buy transaction  - When user gives Intent with Security name, quantity, Order type Stop Limit as entities
* INT_API_BuySecurity{"ENT_Security_Name": "IBM", "ENT_Number": "567", "ENT_Order_Type": "Limit"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "IBM"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "567"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	
	
	
## Buy transaction  - When user gives Intent with Security name, quantity, Order type Stop Limit as entities
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567", "ENT_Order_Type": "Stop Limit"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Stop Limit"}
    - utter_ask_SLOT_ENT_Stop_Price
* enter_data{"ENT_Number": "768.5"}
    - action_store_stop_price
    - slot{"SLOT_ENT_Stop_Price": "768.5"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	

	
## Buy transaction  - When user gives Intent with Security name, quantity, TimeInForce as entities
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567", "ENT_TimeInForce": "Good for the day"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Market"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	

## Buy transaction  - When user gives Intent with quantity, Order type, TimeInForce as entities
* INT_API_BuySecurity{"ENT_Number": "567", "ENT_Order_Type": "Market", "ENT_TimeInForce": "Good for the day"}
	- action_fetch_profile
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart

## Buy transaction  - When user gives Intent with Security name, quantity, Order type, TimeInForce as entities
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Order_Type": "Market", "ENT_TimeInForce": "Good for the day"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart

	
## Buy transaction  - When user gives Intent with Security name, quantity, Order type, TimeInForce as entities
* INT_API_BuySecurity{"ENT_Security_Name": "Netflix", "ENT_Number": "567", "ENT_Order_Type": "Market", "ENT_TimeInForce": "Good for the day"}
	- action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Market"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart
	
	
## Generated Story -338049636648250858 - When user wants to exit from the flow with deny OR canthelp OR human_handoff OR out_of_scope intent
* greet
    - utter_greet
    - utter_inform_availableoptions
* INT_API_BuySecurity
    - action_fetch_profile
    - slot{"ENT_AccountNumber": "983527"}
    - slot{"ENT_Portfolio": "Capital Portfolio - SMA"}
    - slot{"ENT_TradeDate": "01-03-2019"}
    - slot{"ENT_SettlementDate": "01-08-2019"}
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "IBM"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "IBM"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data
    - action_store_order_quantity
    - rewind
* enter_data
    - action_store_order_quantity
    - rewind
* deny OR canthelp OR human_handoff OR out_of_scope
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
    - action_restart
	
## Generated Story -2297314810280013360  - When user wants to exit from the flow with deny OR canthelp OR human_handoff OR out_of_scope intent
* greet
    - utter_greet
    - utter_inform_availableoptions
* INT_API_BuySecurity
    - action_fetch_profile
    - slot{"ENT_AccountNumber": "983527"}
    - slot{"ENT_Portfolio": "Capital Portfolio - SMA"}
    - slot{"ENT_TradeDate": "01-03-2019"}
    - slot{"ENT_SettlementDate": "01-08-2019"}
    - utter_ask_ENT_Security_Name
* enter_data
    - action_store_security_name
    - rewind
* enter_data{"ENT_Security_Name": "ICGGID"}
    - action_store_security_name
    - rewind
* deny OR canthelp OR human_handoff OR out_of_scope
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
    - action_restart


## Buy transaction  - Limit Order flow
* INT_API_BuySecurity
	- action_fetch_profile
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Limit"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "76.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "76.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart	
	
## Buy transaction  - Stop Loss Order flow
* INT_API_BuySecurity
	- action_fetch_profile
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Stop Loss"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Stop Loss"}
    - utter_ask_SLOT_ENT_Stop_Price
* enter_data{"ENT_Number": "768.5"}
    - action_store_stop_price
    - slot{"SLOT_ENT_Stop_Price": "768.5"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart		

## Buy transaction  - Stop Limit Order flow
* INT_API_BuySecurity
	- action_fetch_profile
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Stop Limit"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Stop Limit"}
    - utter_ask_SLOT_ENT_Stop_Price
* enter_data{"ENT_Number": "768.5"}
    - action_store_stop_price
    - slot{"SLOT_ENT_Stop_Price": "768.5"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}	
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good for the day"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good for the day"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart			
	

## Buy transaction  - Stop Limit + "Good till date"  - ask date- Order flow
* INT_API_BuySecurity
	- action_fetch_profile
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Stop Limit"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Stop Limit"}
    - utter_ask_SLOT_ENT_Stop_Price
* enter_data{"ENT_Number": "768.5"}
    - action_store_stop_price
    - slot{"SLOT_ENT_Stop_Price": "768.5"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "45.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "45.8"}	
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good till date"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good till date"}
    - utter_ask_SLOT_ENT_GoodTillDate
* enter_data{"ENT_Date": "11/23/2020"}
    - action_store_goodtilldate
    - slot{"SLOT_ENT_GoodTillDate": "11/23/2020"}	
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart				
	
## Buy transaction  - Limit Order + "Good till date"  - ask date- Order flow
* INT_API_BuySecurity
	- action_fetch_profile
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}
    - utter_ask_SLOT_ENT_Order_Quantity
* enter_data{"ENT_Number": "5342"}
    - action_store_order_quantity
    - slot{"SLOT_ENT_Order_Quantity": "5342"}
    - utter_ask_ENT_Order_Type
* INT_API_BuySecurity{"ENT_Order_Type": "Limit"}
    - action_store_order_type
    - slot{"ENT_Order_Type": "Limit"}
    - utter_ask_SLOT_ENT_Limit_Price
* enter_data{"ENT_Number": "76.8"}
    - action_store_limit_price
    - slot{"SLOT_ENT_Limit_Price": "76.8"}
    - utter_ask_ENT_TimeInForce
* INT_API_BuySecurity{"ENT_TimeInForce": "Good till date"}
    - action_store_timeinforce
    - slot{"ENT_TimeInForce": "Good till date"}
    - utter_ask_SLOT_ENT_GoodTillDate
* enter_data{"ENT_Date": "11/23/2020"}
    - action_store_goodtilldate
    - slot{"SLOT_ENT_GoodTillDate": "11/23/2020"}
    - utter_buy_security_slots_values
    - utter_transaction_confirmation
* affirm
    - utter_thumbsup
    - utter_request_complete
    - utter_inform_availableoptions	
	- action_restart		
	
	
	
	


	
	
##happy_faq holdings - With further details as Yes
* INT_API_ask_holdings
    - action_fetch_profile
	- action_find_holdings
	- utter_holdings_further_details
* INT_API_UI_Navigation{"ENT_UI_Name": "dashboard"}
    - action_fetch_profile
	- action_ui_navigation
    - slot{"ENT_UI_Name": "dashboard"}	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##happy_faq holdings - With further details as No
* INT_API_ask_holdings
    - action_fetch_profile
	- action_find_holdings
	- utter_holdings_further_details
* deny
    - utter_no_further_detail_response
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart	
	
	
##happy_faq+cash holdings
* INT_API_ask_holdings{"ENT_AssetClass":"cash"}
    - action_fetch_profile
	- action_find_holdings
    - slot{"ENT_AssetClass":"cash"}
	- utter_holdings_further_details
* INT_API_UI_Navigation{"ENT_UI_Name": "dashboard"}
    - action_fetch_profile
	- action_ui_navigation
    - slot{"ENT_UI_Name": "dashboard"}	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##happy_faq+IPO holdings
* INT_API_ask_holdings{"ENT_AssetClass":"IPO"}
    - action_fetch_profile
	- action_find_holdings
    - slot{"ENT_AssetClass":"IPO"}
	- utter_holdings_further_details
* INT_API_UI_Navigation{"ENT_UI_Name": "dashboard"}
    - action_fetch_profile
	- action_ui_navigation
    - slot{"ENT_UI_Name": "dashboard"}	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##happy_faq+alternatives holdings
* INT_API_ask_holdings{"ENT_AssetClass":"alternatives"}
    - action_fetch_profile
	- action_find_holdings
	- slot{"ENT_AssetClass":"alternatives"}
	- utter_holdings_further_details
* INT_API_UI_Navigation{"ENT_UI_Name": "dashboard"}
    - action_fetch_profile
	- action_ui_navigation
    - slot{"ENT_UI_Name": "dashboard"}	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##happy_faq+fixed income holdings
* INT_API_ask_holdings{"ENT_AssetClass":"fixed income"}
    - action_fetch_profile
	- action_find_holdings
	- slot{"ENT_AssetClass":"fixed income"}
	- utter_holdings_further_details
* INT_API_UI_Navigation{"ENT_UI_Name": "dashboard"}
    - action_fetch_profile
	- action_ui_navigation
    - slot{"ENT_UI_Name": "dashboard"}	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##happy_faq+equity holdings
* INT_API_ask_holdings{"ENT_AssetClass":"equity"}
    - action_fetch_profile
	- action_find_holdings
	- slot{"ENT_AssetClass":"equity"}
	- utter_holdings_further_details
* INT_API_UI_Navigation{"ENT_UI_Name": "dashboard"}
    - action_fetch_profile
	- action_ui_navigation
    - slot{"ENT_UI_Name": "dashboard"}	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup	
    - utter_inform_availableoptions
	- action_restart

##happy_faq+equity holdings - Do not want to see details
* INT_API_ask_holdings{"ENT_AssetClass":"equity"}
    - action_fetch_profile
	- action_find_holdings
	- slot{"ENT_AssetClass":"equity"}
	- utter_holdings_further_details
* deny
    - utter_no_further_detail_response	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup	
    - utter_inform_availableoptions
	- action_restart	
	
##not_answered_faq holdings
* INT_API_ask_holdings
    - action_fetch_profile
    - action_find_holdings
	- utter_holdings_further_details
* deny
    - utter_no_further_detail_response	
    - utter_faq_confirmation
* deny
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
	- action_restart
   
##not_answered_faq+cash holdings
* INT_API_ask_holdings{"ENT_AssetClass":"cash"}
    - action_fetch_profile
    - action_find_holdings
    - slot{"ENT_AssetClass":"cash"}
	- utter_holdings_further_details
* deny
    - utter_no_further_detail_response	
    - utter_faq_confirmation
* deny
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
	- action_restart
	




##UI Navigation stories - Without entity
* INT_API_UI_Navigation
    - action_fetch_profile
	- action_ui_navigation
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##UI Navigation stories - With entity
* INT_API_UI_Navigation{"ENT_UI_Name": "FX"}
    - action_fetch_profile
	- action_ui_navigation
    - slot{"ENT_UI_Name": "FX"}
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##UI Navigation stories - With entity
* INT_API_UI_Navigation{"ENT_UI_Name": "homepage"}
    - action_fetch_profile
	- action_ui_navigation
    - slot{"ENT_UI_Name": "homepage"}
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##UI Navigation stories - With entity - deny
* INT_API_UI_Navigation{"ENT_UI_Name": "homepage"}
    - action_fetch_profile
	- action_ui_navigation
    - slot{"ENT_UI_Name": "homepage"}
    - utter_faq_confirmation
* deny
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
	- action_restart
	
	
##All Market Info
* INT_API_ask_market_all_info
    - action_fetch_profile
	- action_all_market_info
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart	

##Active stock Info
* INT_API_ask_market_active_stocks_info
    - action_fetch_profile
	- action_active_stock_info
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart		

##Gainer stock Info
* INT_API_ask_market_gainer_stocks_info
    - action_fetch_profile
	- action_gainer_stock_info
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##Loser stock Info
* INT_API_ask_market_loser_stocks_info
    - action_fetch_profile
	- action_loser_stock_info
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart	

	
	
	
##Security rating
* INT_API_ask_market_security_rating_BHS{"ENT_Security_Name": "MSFT"}
    - action_fetch_profile
    - action_store_security_name	
    - slot{"ENT_Security_Name": "MSFT"}
	- action_market_security_rating	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart		

##Security rating - Without entity
* INT_API_ask_market_security_rating_BHS
    - action_fetch_profile
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}	
	- action_market_security_rating	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart
	
##Security rating - with Fund details
* INT_API_ask_market_security_rating_BHS{"ENT_Security_Name": "MSFT", "ENT_Fund_Name": "ABC fund"}
    - action_fetch_profile
    - action_store_security_name	
    - slot{"ENT_Security_Name": "MSFT"}
    - action_store_fund_name	
    - slot{"SLOT_ENT_Fund_Name": "ABC fund"}	
	- action_market_security_rating	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart		

##Security rating - Without entity, with Fund details
* INT_API_ask_market_security_rating_BHS{"ENT_Fund_Name": "ABC fund"}
    - action_fetch_profile
    - action_store_fund_name	
    - slot{"SLOT_ENT_Fund_Name": "ABC fund"}	
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}	
	- action_market_security_rating	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart
	

	
	
	

##Show and Fix the Trade Breaks - With Trade breaks - no fix needed
* INT_API_Show_Fix_TradeBreak
    - action_show_trade_breaks
* enter_data{"ENT_Number": "0"}
    - action_fix_trade_breaks
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
    - action_restart
	
	
##Show and Fix the Trade Breaks - With Trade breaks - Single fix needed, deny at the end
* INT_API_Show_Fix_TradeBreak
    - action_show_trade_breaks
* enter_data{"ENT_AlphaNumeric": "T5342"} OR enter_data{"ENT_AlphaNumeric": "T3454"} OR enter_data{"ENT_AlphaNumeric": "T7422"} OR enter_data{"ENT_AlphaNumeric": "T5349"} OR enter_data{"ENT_AlphaNumeric": "T7236"}
    - action_store_trade_number
* enter_data{"ENT_Number": "0"} OR enter_data{"ENT_Number": "1"}
    - action_fix_trade_breaks
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
    - action_restart	

##Show and Fix the Trade Breaks - With Trade breaks - Single fix needed, deny at the end - Repeat
* INT_API_Show_Fix_TradeBreak
    - action_show_trade_breaks
* enter_data{"ENT_AlphaNumeric": "T1111"}
    - action_store_trade_number
    - slot{"SLOT_ENT_Trade_Number": "T1111"}
* enter_data{"ENT_Number": "0"} OR enter_data{"ENT_Number": "1"}
    - action_fix_trade_breaks
    - utter_faq_confirmation
* deny
    - utter_sorry_and_askto_repeat_question
    - utter_inform_availableoptions
	- action_restart	
	
	
##Show and Fix the Trade Breaks - With Trade breaks - User provided Trade number directly
* INT_API_Show_Fix_TradeBreak{"ENT_AlphaNumeric": "T5342"}
    - action_store_trade_number
    - slot{"SLOT_ENT_Trade_Number": "T5342"}
* enter_data{"ENT_Number": "0"} OR enter_data{"ENT_Number": "1"}
    - action_fix_trade_breaks
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
    - action_restart	
	
	


##Opposite Security rating FAQ
* INT_API_ask_opposite_rating_info{"ENT_Security_Name": "MSFT", "ENT_Fund_Name": "ABC fund"}
    - action_fetch_profile
    - action_store_security_name	
    - slot{"ENT_Security_Name": "MSFT"}
    - action_store_fund_name	
    - slot{"SLOT_ENT_Fund_Name": "ABC fund"}
	- utter_opposite_rating_info
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart		

##Opposite Security rating FAQ - Without Security name
* INT_API_ask_opposite_rating_info{"ENT_Fund_Name": "ABC fund"}
    - action_fetch_profile
    - action_store_fund_name	
    - slot{"SLOT_ENT_Fund_Name": "ABC fund"}	
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}	
	- utter_opposite_rating_info	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

##Opposite Security rating FAQ - Without Fund Name 
* INT_API_ask_opposite_rating_info{"ENT_Security_Name": "Netflix"}
    - action_fetch_profile
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}		
    - utter_ask_ENT_Fund_Name
* enter_data{"ENT_Fund_Name": "ABC fund"}
    - action_store_fund_name	
    - slot{"SLOT_ENT_Fund_Name": "ABC fund"}	
	- utter_opposite_rating_info	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart


##Opposite Security rating FAQ - Without Security name and Fund Name
* INT_API_ask_opposite_rating_info
    - action_fetch_profile	
    - utter_ask_ENT_Fund_Name
* enter_data{"ENT_Fund_Name": "ABC fund"}
    - action_store_fund_name	
    - slot{"SLOT_ENT_Fund_Name": "ABC fund"}	
    - utter_ask_ENT_Security_Name
* enter_data{"ENT_Security_Name": "Netflix"}
    - action_store_security_name
    - slot{"ENT_Security_Name": "Netflix"}		
	- utter_opposite_rating_info	
    - utter_faq_confirmation
* affirm
    - utter_thumbsup
    - utter_inform_availableoptions
	- action_restart

	
	

	
## Plain Greet
* greet OR affirm
    - utter_greet
    - utter_inform_availableoptions
	
## bye
* bye
    - utter_bye

## thanks
* thank
    - utter_noworries

## chitchat
* ask_whatspossible OR ask_howdoing OR ask_whoisit
    - action_chitchat

## chitchat
* human_handoff
    - utter_contact_email
	
## chitchat2
* greet
    - utter_greet
    - utter_inform_availableoptions
* human_handoff
    - utter_contact_email	

	
## chitchat
* out_of_scope
    - utter_out_of_scope
	- action_default_fallback
    - utter_inform_availableoptions
	
## say enter data outside the flows
* greet
    - utter_greet
    - utter_inform_availableoptions

## deny ask_whatspossible
* ask_whatspossible
    - action_chitchat
* deny
    - utter_nohelp
	
## ask_whatspossible
* greet
	- utter_greet
    - utter_inform_availableoptions
* ask_whatspossible
    - action_chitchat	
	
